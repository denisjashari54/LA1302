// app.js
import Router from './router.js';
import { porschePage } from './porsche.js';

// ...andere Imports

const router = new Router();
router.addRoute('porsche', porschePage);
// ...andere Routen hinzufügen

// Optional: Definieren Sie eine Startseite oder eine 404-Seite
router.addRoute('/', homePage);
router.addRoute('404', notFoundPage);
