export function porschePage() {
    // Basis-HTML-Struktur für die Porsche-Seite
    const html = `
      <div class="auto-overview">
        <h1>Porsche Autos</h1>
        <div class="auto-item">
          <h2>Modell 911</h2>
          <p>Spezifikationen: 3.0L H6 Turbo, 379 PS, 0-100 km/h in 4.2 Sekunden</p>
          <p>Preis: ab 120.000€</p>
        </div>
        <div class="auto-item">
          <h2>Modell Cayenne</h2>
          <p>Spezifikationen: 3.0L V6 Turbo, 335 PS, 0-100 km/h in 6.2 Sekunden</p>
          <p>Preis: ab 75.000€</p>
        </div>
        <!-- Weitere Modelle hier einfügen -->
      </div>
    `;

    // Füge das HTML in das Hauptelement der Anwendung ein
    document.getElementById('app').innerHTML = html;

    // Füge hier zusätzliche JS-Logik hinzu, z.B. Event-Listener
}

// Zusätzliche Funktionen können hier definiert werden, z.B. um Daten dynamisch zu laden
