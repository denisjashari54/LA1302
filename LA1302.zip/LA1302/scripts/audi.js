// app.js
import router from './router.js';
import { homePage } from './home.js';
import { carsPage } from './cars.js';
// ...other imports

router.addRoute('/', homePage);
router.addRoute('/cars', carsPage);
// ...other routes

window.addEventListener('load', () => router.handleRouteChange());
window.addEventListener('hashchange', () => router.handleRouteChange());
