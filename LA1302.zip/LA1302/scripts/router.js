// router.js
class Router {
    constructor() {
        this.routes = {};
        // Initialisiere den Router, sobald das Fenster geladen ist
        window.addEventListener('load', this.handleRouteChange.bind(this));
        // Reagiere auf Änderungen in der URL
        window.addEventListener('hashchange', this.handleRouteChange.bind(this));
    }

    addRoute(route, action) {
        this.routes[route] = action;
    }

    handleRouteChange() {
        let url = window.location.hash.slice(1) || '/';
        let action = this.routes[url];
        if (action) {
            action();
        } else {
            // Fehlerbehandlung: Zeige eine 404 Seite oder eine Standardseite
            console.error(`Route "${url}" not found`);
            // Optional: Füge hier eine Standardaktion hinzu, z.B. Laden der Startseite
        }
    }
}

// Export the router
export default new Router();
